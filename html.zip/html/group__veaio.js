var group__veaio =
[
    [ "ve_aio_init", "group__veaio.html#gac04a80af1c8a785724bfd4a501096ab7", null ],
    [ "ve_aio_fini", "group__veaio.html#ga6bf208367c4381fbd161a420c3cb1c48", null ],
    [ "ve_aio_read", "group__veaio.html#ga9beab2b6a401b025cbb931205e93acca", null ],
    [ "ve_aio_write", "group__veaio.html#ga7ea114dccdd5d6030c648cc66dde38a1", null ],
    [ "ve_aio_query", "group__veaio.html#gac134802db58fcdf2d581681c4af8e574", null ],
    [ "ve_aio_wait", "group__veaio.html#ga667a5ae7564e7db279f10719ded0caf7", null ]
];