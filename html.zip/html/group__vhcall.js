var group__vhcall =
[
    [ "vhcall_install", "group__vhcall.html#gaad93c08018928af1b35b94bb110b9c2b", null ],
    [ "vhcall_find", "group__vhcall.html#ga7d7ad2f1f6ee25c73ca8ec99672ec319", null ],
    [ "vhcall_invoke", "group__vhcall.html#gaf8b07d9022faea59d60c8850f5c248fa", null ],
    [ "vhcall_uninstall", "group__vhcall.html#ga14e45d064daecd926d1719b05fe1936d", null ]
];