var group__vedma =
[
    [ "ve_dma_handle_t", "structve__dma__handle__t.html", [
      [ "status", "group__vedma.html#gaa93ceff694974d6646042b9aaae82dbf", null ],
      [ "index", "group__vedma.html#ga93e2ecaf3459095fe525693680013be7", null ]
    ] ],
    [ "ve_dma_init", "group__vedma.html#ga31de04f5ff54fa396d9e94e92d4132ab", null ],
    [ "ve_dma_post", "group__vedma.html#gab9e0242a84fd9b5fb3c2f8f2c6c114e0", null ],
    [ "ve_dma_poll", "group__vedma.html#ga68d3ed9db092003f6b3df1f936551c00", null ],
    [ "ve_dma_post_wait", "group__vedma.html#ga6b9b4a101569a34e339506c9488951b9", null ],
    [ "ve_dma_read_ctrl_reg", "group__vedma.html#gaf50440b91b1544ed7bef388dfa646615", null ],
    [ "ve_register_mem_to_dmaatb", "group__vedma.html#gac872c4f4bc3b428e0e59e5c8d4cff763", null ],
    [ "ve_unregister_mem_from_dmaatb", "group__vedma.html#ga73e1a51f16a4c4ddf8486659eebcfba5", null ]
];