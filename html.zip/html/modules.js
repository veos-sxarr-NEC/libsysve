var modules =
[
    [ "VE DMA (EXPERIMENTAL)", "group__vedma.html", "group__vedma" ],
    [ "VE AIO", "group__veaio.html", "group__veaio" ],
    [ "VH call", "group__vhcall.html", "group__vhcall" ],
    [ "VH-VE SHM", "group__vhshm.html", "group__vhshm" ]
];