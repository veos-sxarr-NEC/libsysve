var modules =
[
    [ "VE DMA", "group__vedma.html", "group__vedma" ],
    [ "Accelerated I/O", "group__veaccio.html", null ],
    [ "MISC", "group__misc.html", "group__misc" ],
    [ "VE AIO", "group__veaio.html", "group__veaio" ],
    [ "VH call", "group__vhcall.html", "group__vhcall" ],
    [ "VH-VE SHM", "group__vhshm.html", "group__vhshm" ]
];