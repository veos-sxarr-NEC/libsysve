var annotated =
[
    [ "ve_dma_handle_t", "structve__dma__handle__t.html", "structve__dma__handle__t" ]
];