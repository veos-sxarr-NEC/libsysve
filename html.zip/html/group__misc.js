var group__misc =
[
    [ "ve_get_numa_node", "group__misc.html#ga94946aa87071fe5f1a58e1e89f45b415", null ]
];