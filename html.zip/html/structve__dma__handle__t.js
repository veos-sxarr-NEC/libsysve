var structve__dma__handle__t =
[
    [ "status", "group__vedma.html#gaa93ceff694974d6646042b9aaae82dbf", null ],
    [ "index", "group__vedma.html#ga93e2ecaf3459095fe525693680013be7", null ]
];